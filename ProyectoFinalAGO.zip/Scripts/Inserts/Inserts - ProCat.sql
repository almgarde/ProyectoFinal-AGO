--------------------------------------------------------
-- Archivo creado  - viernes-junio-10-2022   
--------------------------------------------------------
REM INSERTING into PF_AGO.PROFESSIONAL_CATEGORIES
SET DEFINE OFF;
Insert into PF_AGO.PROFESSIONAL_CATEGORIES (ID_PRO_CAT,NAME_PRO_CAT,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('1','Catedr�ticos','Admin',to_date('10/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.PROFESSIONAL_CATEGORIES (ID_PRO_CAT,NAME_PRO_CAT,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('2','Investigadores Cient�ficos','Admin',to_date('10/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.PROFESSIONAL_CATEGORIES (ID_PRO_CAT,NAME_PRO_CAT,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('3','Profesores Titulares','Admin',to_date('10/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.PROFESSIONAL_CATEGORIES (ID_PRO_CAT,NAME_PRO_CAT,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('4','Investigadora Postdoctoral','Admin',to_date('10/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.PROFESSIONAL_CATEGORIES (ID_PRO_CAT,NAME_PRO_CAT,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('5','Doctores Contratados','Admin',to_date('10/06/22','DD/MM/RR'),'1');
