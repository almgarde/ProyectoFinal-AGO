--------------------------------------------------------
-- Archivo creado  - viernes-junio-10-2022   
--------------------------------------------------------
REM INSERTING into PF_AGO.TECHNICAL_CATEGORIES
SET DEFINE OFF;
Insert into PF_AGO.TECHNICAL_CATEGORIES (ID_TECH_CAT,NAME_TECH_CAT,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('1','Moliendas','Admin',to_date('10/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.TECHNICAL_CATEGORIES (ID_TECH_CAT,NAME_TECH_CAT,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('2','Rayos-X','Admin',to_date('10/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.TECHNICAL_CATEGORIES (ID_TECH_CAT,NAME_TECH_CAT,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('3','Preparaci�n Metalogr�fica','Admin',to_date('10/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.TECHNICAL_CATEGORIES (ID_TECH_CAT,NAME_TECH_CAT,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('4','Microscop�a Electr�nica','Admin',to_date('10/06/22','DD/MM/RR'),'1');
