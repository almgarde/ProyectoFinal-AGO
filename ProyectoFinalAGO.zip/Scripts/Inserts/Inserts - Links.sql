--------------------------------------------------------
-- Archivo creado  - s�bado-junio-11-2022   
--------------------------------------------------------
REM INSERTING into PF_AGO.LINKS
SET DEFINE OFF;
Insert into PF_AGO.LINKS (ID_LINK,TITLE_LINK,IMAGE_LINK,URL_LINK,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('1','Instituto de Ciencia de Materiales de Sevilla (ICMS)','1icms.jpg','https://www.icms.us-csic.es/','Admin',to_date('11/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.LINKS (ID_LINK,TITLE_LINK,IMAGE_LINK,URL_LINK,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('2','Centro de Investigaciones Cient�ficas (CicCartuja)','2cic.jpg','https://www.ciccartuja.es/inicio/','Admin',to_date('11/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.LINKS (ID_LINK,TITLE_LINK,IMAGE_LINK,URL_LINK,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('3','Universidad de Sevilla (US)','3US.png','https://www.us.es/','Admin',to_date('11/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.LINKS (ID_LINK,TITLE_LINK,IMAGE_LINK,URL_LINK,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('4','Escuela T�cnica Superior de Ingenier�a - Universidad de Sevilla (ETSI)','4etsi.png','https://www.etsi.us.es/','Admin',to_date('11/06/22','DD/MM/RR'),'1');
