function getDatatableProjects() {

	let table = $('#projectsDatatable').DataTable({
		"sAjaxSource": "/management/getProjectsData",
		"sAjaxDataProp": "",
		"orderCellsTop": true,
		"fixedHeader": false,
		"bAutoWidth": false,
		"language": {
			"lengthMenu": $('#labelMostrando').val() + ' _MENU_ ' + $('#labelEntradas').val(),
			"emptyTable": $('#labelTablaVacia').val(),
			"search": $('#labelBuscador').val(),
			"zeroRecords": $('#labelNoCoincidencias').val(),
			"info": $('#labelMostrando').val() + ' _START_ ' + $('#labelA').val() + ' _END_ ' + $('#labelDe').val() + ' _TOTAL_ ' + $('#labelEntradas').val(),
			"infoEmpty": $('#labelMostrando').val() + " 0 " + $('#labelA').val() + ' 0 ' + $('#labelDe').val() + ' 0 ' + $('#labelEntradas').val(),
			"infoFiltered": '(' + $('#labelFiltrado').val() + ' _MAX_ ' + $('#labelEntradas').val() + ')',
			"loadingRecords": $('#labelCargando').val(),
			"paginate": {
				"next": $('#labelSiguiente').val(),
				"previous": $('#labelAnterior').val()
			},
		},
		"order": [[0, "desc"]],
		"aoColumns": [
			{
				"mData": "idProject",
				"mRender": function(data, type, row) {
					return data;
				},
				"bSortable": true
			},
			{
				"mData": "titleProject",
				"mRender": function(data, type, row) {
					return data;
				},
				"bSortable": false
			},

			{
				"mData": "imageProject",
				"mRender": function(data, type, row) {
					return data;
				},
				"bSortable": false
			},
			{
				"mData": "descriptionProject",
				"mRender": function(data, type, row) {
					return data;
				},
				"bSortable": false
			},
			{
				"mData": "admin",
				"mRender": function(data, type, row) {
					return data;
				},
				"bSortable": true
			},
			{
				"mData": "date",
				"mRender": function(data, type, row) {
					return data;
				},
				"bSortable": true
			},
			{
				"mData": "active",
				"mRender": function(data, type, row) {
					return data;
				},
				"bSortable": true
			},

			{
				"mData": null,
				"bSortable": false
			}
		],
		"fnCreatedRow": function(row, data, index) {

			// Imagen 	
			var verImage = $('<a/>', {
				text: $('#imageProjectLabel').val(),
				href: '',
				click: function(e) {
					e.preventDefault();
					//$('#newsDatatable').DataTable().ajax.reload();
					mostrarModalProjectsImage(data.titleProject, data.imageProject);
				}
			});

			$('td:eq(2)', row).html(verImage);


			// Abstract
			var verAbstract = $('<a/>', {
				text: $('#descriptionProjectLabel').val(),
				href: '',
				click: function(e) {
					e.preventDefault();
					mostrarModalProjectsDescription(data.titleProject, data.descriptionProject);
				}
			});

			$('td:eq(3)', row).html(verAbstract);


			// Activo 
			var activo;
			if (data.active == 'true') {
				activo = $('<a/>', {
					text: $('#activoSi').val()
				});
			} else {
				activo = $('<a/>', {
					text: $('#activoNo').val()
				});
			}
			$('td:eq(6)', row).html(activo);


			// Acciones 

			var liAccion1 = $('<li/>');
			var accion1 = $('<a/>', {
				text: $('#linkEditar').val(),
				href: '',
				click: function(e) {
					e.preventDefault();
					mostrarModalUpdateProjects(data.idProject, data.titleProject, data.descriptionProject, data.active);
				}
			});

			accion1.addClass('dropdown-item').attr('href', '#');
			liAccion1.append(accion1);


			var liAccion2 = $('<li/>');
			var accion2 = $('<a/>', {
				text: $('#linkCambiarFoto').val(),
				href: '',
				click: function(e) {

					e.preventDefault();
					mostrarModalUpdateImageProjects(data.idProject);
				}
			});

			accion2.addClass('dropdown-item').attr('href', '#');
			liAccion2.append(accion2);


			var liAccion3 = $('<li/>');
			var accion3 = $('<a/>', {
				text: $('#linkGenerarPdf').val(),
				href: '/management/generatePdf/projects/' + data.idProject,
				click: function(e) {
					e.preventDefault();
					window.open(this, '_blank');
					return false;
				}
			});

			accion3.addClass('dropdown-item');
			liAccion3.append(accion3);


			var liAccion4 = $('<li/>');
			var accion4 = $('<a/>', {
				text: $('#linkEliminar').val(),
				href: '',
				click: function(e) {
					e.preventDefault();
					mostrarModalDeleteProjects(data.idProject);
				}
			});

			accion4.addClass('dropdown-item').attr('href', '#');
			liAccion4.append(accion4);


			var divAcciones = $('<div/>');
			divAcciones.addClass("text-end");

			var liPrincipal = $('<li/>').css('list-style-type', 'none').addClass('nav-item').addClass('dropdown');
			var aPrincipal = $('<a/>').addClass('nav-link').addClass('dropdown-toggle').attr('href', '#').attr('id', 'listaAcciones').attr('role', 'button').attr('data-bs-toggle', 'dropdown').attr('aria-expanded', 'false').text($('#linkAcciones').val());
			var uPrincipal = $('<u/>').addClass('dropdown-menu').attr('aria-labelledby', 'listaAcciones').css('text-decoration', 'none');

			liPrincipal.append(aPrincipal);
			aPrincipal.append(uPrincipal);
			uPrincipal.append(liAccion1);
			uPrincipal.append(liAccion2);
			uPrincipal.append(liAccion3);
			uPrincipal.append(liAccion4);

			divAcciones.append(liPrincipal);

			$('td:eq(7)', row).html(divAcciones);


			$('td:eq(0)', row).attr("data-label", $('#idDataLabel').val());
			$('td:eq(1)', row).attr("data-label", $('#titleProjectLabel').val());
			$('td:eq(2)', row).attr("data-label", $('#imageProjectLabel').val());
			$('td:eq(3)', row).attr("data-label", $('#descriptionProjectLabel').val());
			$('td:eq(4)', row).attr("data-label", $('#adminDataLabel').val());
			$('td:eq(5)', row).attr("data-label", $('#dateDataLabel').val());
			$('td:eq(6)', row).attr("data-label", $('#activeDataLabel').val());
			$('td:eq(7)', row).attr("data-label", "");

		}
	});



	// FILTROS

	$('#projectsDatatable thead tr').clone(true).addClass('filters').appendTo('#projectsDatatable thead');

	$('#projectsDatatable thead tr.filters th').each(function() {
		$(this).off();
		$(this).removeClass('sorting_desc');
		$(this).removeClass('sorting');
	});

	$('#projectsDatatable thead tr:eq(1) th.atri').each(function(i) {

		$(this).html('<input type="text" />');

		$('input', this).on('keyup change', function() {
			if (table.column(i).search() != this.value) {
				table.column(i).search(this.value).draw();
			}
		});
	});

	$('#projectsDatatable thead tr:eq(1) th.selectActive').each(function(i) {

		$(this).html('<select class="form-select"><option value=""><option value="true">' + $('#activoSi').val() + '</option><option value="false">' + $('#activoNo').val() + '</option></select>');

		$('select', this).on('keyup change', function() {
			if (table.column(6).search() !== this.value) {
				table.column(6).search(this.value).draw();
			}
		});
	});


	// BOTONES 

	$(document).on("click", "#btnAceptarAddProjects", function(e) {

		$('#modalAddProjects').modal('show');
		var form = $("#formAddProjects");

		if (form[0].checkValidity() === false) {
			e.preventDefault();
			e.stopPropagation();
		} else {
			anyadirNuevoProyecto();

		}
		form.addClass('was-validated');

	});

	$(document).on("click", "#btnCancelarAddProjects", function() {
		$("#formAddProjects").removeClass('was-validated');
		$('#titleProjectMaxContador').html(max_chars_content);
		$('#descriptionProjectMaxContador').html(max_chars_content);
		$(".mensajeError").hide();
		$(".mensajeError").text('');
		$("#titleProjects").val('');
		$("#imageProjects").val('');
		$("#descProjects").val('');
		$("#active").val('1');
	});

	$(document).on("click", "#btnCloseAddProjects", function() {
		$("#formAddProjects").removeClass('was-validated');
		$('#titleProjectMaxContador').html(max_chars_content);
		$('#descriptionProjectMaxContador').html(max_chars_content);
		$(".mensajeError").hide();
		$(".mensajeError").text('');
		$("#titleProjects").val('');
		$("#imageProjects").val('');
		$("#descProjects").val('');
		$("#active").val('1');
	});

	$("#modalAddProjects").on('hide.bs.modal', function() {
		$("#formAddProjects").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
	});

	$(document).on("click", "#btnAceptarUpdateProjects", function(e) {

		$('#modalUpdateProjects').modal('show');
		var form = $("#formUpdateProjects");

		if (form[0].checkValidity() === false) {
			e.preventDefault();
			e.stopPropagation();
		} else {
			editarProyecto();

		}
		form.addClass('was-validated');

	});

	$(document).on("click", "#btnCancelarUpdateProjects", function(e) {
		$("#formUpdateProjects").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
	});

	$(document).on("click", "#btnCloseUpdateProjects", function(e) {
		$("#formUpdateProjects").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
	});

	$("#modalUpdateProjects").on('hide.bs.modal', function() {
		$("#formUpdateProjects").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
	});

	$(document).on("click", "#btnAceptarUpdateImageProjects", function(e) {

		$('#modalUpdateImageProjects').modal('show');
		var form = $("#formUpdateImageProjects");

		if (form[0].checkValidity() === false) {
			e.preventDefault();
			e.stopPropagation();
		} else {
			editarImagenProyecto();
			$('#modalUpdateImageProjects').modal('hide');
		}
		form.addClass('was-validated');

	});

	$(document).on("click", "#btnCancelarUpdateImageProjects", function(e) {
		$("#formUpdateImageProjects").removeClass('was-validated');
	});

	$(document).on("click", "#btnCloseUpdateImageProjects", function(e) {
		$("#formUpdateImageProjects").removeClass('was-validated');
	});

	$("#modalUpdateImageProjects").on('hide.bs.modal', function() {
		$("#formUpdateImageProjects").removeClass('was-validated');
	});

	$(document).on("click", "#btnAceptarDeleteProjects", function(e) {
		e.preventDefault();
		eliminarProyecto();
	});


	// MÁXIMO CARACTERES TEXTAREA

	var max_chars_content = 3500;


	$('#titleProjectMaxContador').html(max_chars_content);

	$('#titleProjects').keyup(function() {
		var chars = $(this).val().length;
		var diff = max_chars_content - chars;
		$('#titleProjectMaxContador').html(diff);

	});

	$('#descriptionProjectMaxContador').html(max_chars_content);

	$('#descProjects').keyup(function() {
		var chars = $(this).val().length;
		var diff = max_chars_content - chars;
		$('#descriptionProjectMaxContador').html(diff);

	});


	$('#titleProjectsEdit').keyup(function() {
		var chars = $(this).val().length;
		var diff = max_chars_content - chars;
		$('#titleProjectMaxContadorEdit').html(diff);

	});

	$('#descProjectsEdit').keyup(function() {
		var chars = $(this).val().length;
		var diff = max_chars_content - chars;
		$('#descriptionProjectMaxContadorEdit').html(diff);

	});

}


// MODALES

function mostrarModalProjectsImage(titleProject, imagen) {
	$("#headerModalImageProject").text(titleProject);
	$('#bodyModalImageProject').attr('src', 'images/' + imagen);
	$('#modalImageProject').modal('toggle');
}

function mostrarModalProjectsDescription(titleProject, descriptionProject) {
	$("#modalDescriptionProject").modal('toggle');
	$("#headerModalDescriptionProject").text(titleProject);
	$("#bodyModalDescriptionProject").text(descriptionProject);
}


function mostrarModalAddProjects() {
	$("#modalAddProjects").modal('toggle');
	$(".mensajeError").hide();
	$(".mensajeError").text('');
}

function mostrarModalUpdateProjects(idProject, titleProject, descriptionProject, active) {
	$(".mensajeError").hide();
	$(".mensajeError").text('');
	$('#titleProjectsEdit').val(titleProject);
	$('#descProjectsEdit').val(descriptionProject);
	$('#idProjectUpdate').val(idProject);

	if (active == 'true') {
		$('#activeEdit').val('1');
	} else {
		$('#activeEdit').val('0');
	}

	var charsInit = titleProject.length;
	var diffInit = 3500 - charsInit;
	$('#titleProjectMaxContadorEdit').html(diffInit);

	var charsInit = descriptionProject.length;
	var diffInit = 3500 - charsInit;
	$('#descriptionProjectMaxContadorEdit').html(diffInit);

	$("#modalUpdateProjects").modal('toggle');
}

function mostrarModalUpdateImageProjects(idProject) {
	$('#idProjectUpdateImage').val(idProject);
	$("#modalUpdateImageProjects").modal('toggle');
}

function mostrarModalDeleteProjects(idProject) {
	$('#idProjectsDelete').val(idProject);
	$("#modalDeleteProjects").modal('toggle');
}


// FUNCIONES CRUD

function anyadirNuevoProyecto() {

	let form = new FormData();

	form.append("file", $('#imageProjects')[0].files[0]);
	form.append("titleProjects", $("#titleProjects").val());
	form.append("descProjects", $("#descProjects").val());
	form.append("active", $("#active").val());
	form.append("inputUser", $("#inputUser").val());

	$.ajax({
		url: '/management/addProjectsData',
		type: "POST",
		processData: false,
		contentType: false,
		data: form,
		success: function(data) {
			okMessage();
			$(".alert").text($("#addOkMensaje").val());
		},
		error: function(e) {
			$('#modalAddProjects').modal('show');
			$("#formAddProjects").removeClass('was-validated');
			$(".mensajeError").show();

			if (e.responseText == "titleProjectsUnique") {
				$(".mensajeError").text($('#titleProjectsUnique').val());
			} else {
				$(".mensajeError").hide();
				$(".mensajeError").text('');
				$('#modalAddProjects').modal('hide');
				errorMessage();
				$(".alert").text($('#addErrorMensaje').val());
			}
		}
	}).done(function() {
		$("#formAddProjects").removeClass('was-validated');
		$('#modalAddProjects').modal('hide');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
		$("#titleProjects").val('');
		$("#imageProjects").val('');
		$("#descProjects").val('');
		$("#active").val('1');
		$('#projectsDatatable').DataTable().ajax.reload();
	});
}


function editarProyecto() {

	let form = new FormData();

	form.append("idProject", $("#idProjectUpdate").val());
	form.append("titleProject", $("#titleProjectsEdit").val());
	form.append("descProject", $("#descProjectsEdit").val());
	form.append("active", $("#activeEdit").val());
	form.append("inputUser", $("#inputUser").val());

	$.ajax({
		url: '/management/updateProjectsData',
		type: "POST",
		processData: false,
		contentType: false,
		data: form,
		success: function(data) {
			okMessage();
			$(".alert").text($("#updateOkMensaje").val());
		},
		error: function(e) {
			$('#modalUpdateProjects').modal('show');
			$("#formUpdateProjects").removeClass('was-validated');
			$(".mensajeError").show();

			if (e.responseText == "titleProjectsUnique") {
				$(".mensajeError").text($('#titleProjectsUnique').val());
			} else {
				$(".mensajeError").hide();
				$(".mensajeError").text('');
				$('#modalUpdateProjects').modal('hide');
				errorMessage();
				$(".alert").text($('#updateErrorMensaje').val());
			}
		}
	}).done(function() {
		$("#formUpdateProjects").removeClass('was-validated');
		$('#modalUpdateProjects').modal('hide');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
		$('#projectsDatatable').DataTable().ajax.reload();
	});
}


function editarImagenProyecto() {

	let form = new FormData();

	form.append("file", $('#imageProjectsEdit')[0].files[0]);
	form.append("idProject", $("#idProjectUpdateImage").val());
	form.append("inputUser", $("#inputUser").val());

	$.ajax({
		url: '/management/updateImageProjectsData',
		type: "POST",
		processData: false,
		contentType: false,
		data: form,
		success: function(data) {
			okMessage();
			$(".alert").text($("#updateOkMensaje").val());
		},
		error: function(data) {
			errorMessage();
			$(".alert").text($("#updateErrorMensaje").val());
		}
	}).done(function() {
		$("#formUpdateImageProjects").removeClass('was-validated');
		$("#imageProjectsEdit").val('');
		$('#projectsDatatable').DataTable().ajax.reload();
	});
}


function eliminarProyecto() {

	let form = new FormData();

	form.append("idProject", $("#idProjectsDelete").val());

	$.ajax({
		url: '/management/deleteProjectsData',
		type: "POST",
		processData: false,
		contentType: false,
		data: form,
		success: function(data) {
			okMessage();
			$(".alert").text($("#deleteOkMensaje").val());
		},
		error: function(data) {
			errorMessage();
			$(".alert").text($("#deleteErrorMensaje").val());
		}
	}).done(function() {
		$('#projectsDatatable').DataTable().ajax.reload();
	});
}