package es.iessoterohernandez.ProyectoFinalAGO.Security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailSendServiceImpl implements EmailSendServiceI {

	@Autowired
	private JavaMailSender mailSender;

	final static Logger LOGGER = LoggerFactory.getLogger(EmailSendServiceImpl.class);

	/**
	 * Permite enviar un email a un usuario
	 * 
	 * @param receiver
	 * @param subject
	 * @param content
	 * @throws Exception
	 */
	@Override
	public Boolean sendEmail(String receiver, String subject, String content) throws Exception {

		LOGGER.info("EmailSendServiceImpl sendEmail .- Inicio");

		Boolean confirm = false;
		try {

			if (receiver != null && subject != null && content != null) {

				SimpleMailMessage email = new SimpleMailMessage();

				email.setTo(receiver);
				email.setSubject(subject);
				email.setText(content);

				mailSender.send(email);
				confirm = true;

				LOGGER.info("EmailSendServiceImpl sendEmail .- Email enviado correctamente");

			} else {
				LOGGER.error("EmailSendServiceImpl sendEmail .- Error: Parámetros de entrada nulos");
			}

		} catch (Exception e) {
			LOGGER.error("EmailSendServiceImpl sendEmail .- Error no controlado al enviar el email");
			throw e;
		}

		LOGGER.info("EmailSendServiceImpl sendEmail .- Fin");
		return confirm;
	}

}
