package es.iessoterohernandez.ProyectoFinalAGO.Services.Dto;

public class ProjectsDto {

	private String titleProject;

	private String imageProject;

	private String descriptionProject;

	public String getTitleProject() {
		return titleProject;
	}

	public void setTitleProject(String titleProject) {
		this.titleProject = titleProject;
	}

	public String getImageProject() {
		return imageProject;
	}

	public void setImageProject(String imageProject) {
		this.imageProject = imageProject;
	}

	public String getDescriptionProject() {
		return descriptionProject;
	}

	public void setDescriptionProject(String descriptionProject) {
		this.descriptionProject = descriptionProject;
	}

}
