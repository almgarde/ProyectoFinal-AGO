--------------------------------------------------------
-- Archivo creado  - viernes-junio-10-2022   
--------------------------------------------------------
REM INSERTING into PF_AGO.FACILITIES
SET DEFINE OFF;
Insert into PF_AGO.FACILITIES (ID_FACILITY,NAME_FACILITY,ID_TECH_CAT,PHOTO_FACILITY,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('1','PULVERISETTE 7','1','1equipo1.jpg','Admin',to_date('10/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.FACILITIES (ID_FACILITY,NAME_FACILITY,ID_TECH_CAT,PHOTO_FACILITY,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('2','PULVERISETTE 4','1','2equipo2.jpg','Admin',to_date('10/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.FACILITIES (ID_FACILITY,NAME_FACILITY,ID_TECH_CAT,PHOTO_FACILITY,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('3','Difract�metro Phillips X�Pert Pro','2','3equipo3.jpg','Admin',to_date('10/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.FACILITIES (ID_FACILITY,NAME_FACILITY,ID_TECH_CAT,PHOTO_FACILITY,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('4','Prensa uniaxial Specac 15011','3','4equipo4.png','Admin',to_date('10/06/22','DD/MM/RR'),'1');
Insert into PF_AGO.FACILITIES (ID_FACILITY,NAME_FACILITY,ID_TECH_CAT,PHOTO_FACILITY,UPDATE_ADMIN,UPDATE_DATE,ACTIVE) values ('5','Microscopio electr�nico de barrido Hitachi S-4800 SEM-FEG','4','5equipo5.jpg','Admin',to_date('10/06/22','DD/MM/RR'),'1');
