package es.iessoterohernandez.ProyectoFinalAGO.Services.Dto.Form;

/**
 * Form DTO entidad: Publications
 * 
 * @author agadelao
 *
 */
public class PublicationsOrderFormDto {

	private Boolean ascendente;

	public Boolean getAscendente() {
		return ascendente;
	}

	public void setAscendente(Boolean ascendente) {
		this.ascendente = ascendente;
	}

}
