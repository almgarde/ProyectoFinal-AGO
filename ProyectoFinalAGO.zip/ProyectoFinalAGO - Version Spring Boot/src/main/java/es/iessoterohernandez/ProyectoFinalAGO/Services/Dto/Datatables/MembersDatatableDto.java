package es.iessoterohernandez.ProyectoFinalAGO.Services.Dto.Datatables;

public class MembersDatatableDto {

	private String idMember;

	private String nameMember;

	private String shortNameMember;

	private String dniMember;

	private String emailMember;

	private String phoneMember;

	private String activeProCat;

	private String nameProCat;

	private String idProCat;

	private String photoMember;

	private String reseachIdMember;

	private String scopusIdMember;

	private String orcIdMember;

	private String trajectoryMember;

	private String active;

	private String admin;

	private String date;

	public String getIdMember() {
		return idMember;
	}

	public void setIdMember(String idMember) {
		this.idMember = idMember;
	}

	public String getNameMember() {
		return nameMember;
	}

	public void setNameMember(String nameMember) {
		this.nameMember = nameMember;
	}

	public String getShortNameMember() {
		return shortNameMember;
	}

	public void setShortNameMember(String shortNameMember) {
		this.shortNameMember = shortNameMember;
	}

	public String getDniMember() {
		return dniMember;
	}

	public void setDniMember(String dniMember) {
		this.dniMember = dniMember;
	}

	public String getEmailMember() {
		return emailMember;
	}

	public void setEmailMember(String emailMember) {
		this.emailMember = emailMember;
	}

	public String getPhoneMember() {
		return phoneMember;
	}

	public void setPhoneMember(String phoneMember) {
		this.phoneMember = phoneMember;
	}

	public String getActiveProCat() {
		return activeProCat;
	}

	public void setActiveProCat(String activeProCat) {
		this.activeProCat = activeProCat;
	}

	public String getNameProCat() {
		return nameProCat;
	}

	public void setNameProCat(String nameProCat) {
		this.nameProCat = nameProCat;
	}

	public String getIdProCat() {
		return idProCat;
	}

	public void setIdProCat(String idProCat) {
		this.idProCat = idProCat;
	}

	public String getPhotoMember() {
		return photoMember;
	}

	public void setPhotoMember(String photoMember) {
		this.photoMember = photoMember;
	}

	public String getReseachIdMember() {
		return reseachIdMember;
	}

	public void setReseachIdMember(String reseachIdMember) {
		this.reseachIdMember = reseachIdMember;
	}

	public String getScopusIdMember() {
		return scopusIdMember;
	}

	public void setScopusIdMember(String scopusIdMember) {
		this.scopusIdMember = scopusIdMember;
	}

	public String getOrcIdMember() {
		return orcIdMember;
	}

	public void setOrcIdMember(String orcIdMember) {
		this.orcIdMember = orcIdMember;
	}

	public String getTrajectoryMember() {
		return trajectoryMember;
	}

	public void setTrajectoryMember(String trajectoryMember) {
		this.trajectoryMember = trajectoryMember;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

}
