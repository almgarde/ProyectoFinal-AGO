package es.iessoterohernandez.ProyectoFinalAGO.Services.Dto.Datatables;

public class ProCatDatatableDto {

	private String idProCat;

	private String nameProCat;

	private String active;

	private String admin;

	private String date;

	public String getIdProCat() {
		return idProCat;
	}

	public void setIdProCat(String idProCat) {
		this.idProCat = idProCat;
	}

	public String getNameProCat() {
		return nameProCat;
	}

	public void setNameProCat(String nameProCat) {
		this.nameProCat = nameProCat;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

}
