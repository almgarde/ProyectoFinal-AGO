package es.iessoterohernandez.ProyectoFinalAGO.Services.Dto.Datatables;

public class FacilitiesDatatableDto {

	private String idFacility;

	private String nameFacility;

	private String idTechCat;

	private String nameTechCat;

	private String activeTechCat;

	private String photoFacility;

	private String featuresFacility;

	private String active;

	private String admin;

	private String date;

	public String getIdFacility() {
		return idFacility;
	}

	public void setIdFacility(String idFacility) {
		this.idFacility = idFacility;
	}

	public String getNameFacility() {
		return nameFacility;
	}

	public void setNameFacility(String nameFacility) {
		this.nameFacility = nameFacility;
	}

	public String getIdTechCat() {
		return idTechCat;
	}

	public void setIdTechCat(String idTechCat) {
		this.idTechCat = idTechCat;
	}

	public String getNameTechCat() {
		return nameTechCat;
	}

	public void setNameTechCat(String nameTechCat) {
		this.nameTechCat = nameTechCat;
	}

	public String getActiveTechCat() {
		return activeTechCat;
	}

	public void setActiveTechCat(String activeTechCat) {
		this.activeTechCat = activeTechCat;
	}

	public String getPhotoFacility() {
		return photoFacility;
	}

	public void setPhotoFacility(String photoFacility) {
		this.photoFacility = photoFacility;
	}

	public String getFeaturesFacility() {
		return featuresFacility;
	}

	public void setFeaturesFacility(String featuresFacility) {
		this.featuresFacility = featuresFacility;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

}
