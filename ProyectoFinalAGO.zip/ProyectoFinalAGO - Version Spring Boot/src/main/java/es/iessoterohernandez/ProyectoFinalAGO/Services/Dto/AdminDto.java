package es.iessoterohernandez.ProyectoFinalAGO.Services.Dto;

public class AdminDto {

	private String nameAdmin;

	private String emailAdmin;

	public String getNameAdmin() {
		return nameAdmin;
	}

	public void setNameAdmin(String nameAdmin) {
		this.nameAdmin = nameAdmin;
	}

	public String getEmailAdmin() {
		return emailAdmin;
	}

	public void setEmailAdmin(String emailAdmin) {
		this.emailAdmin = emailAdmin;
	}

}
