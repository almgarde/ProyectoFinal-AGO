package es.iessoterohernandez.ProyectoFinalAGO.Security;

public interface EmailSendServiceI {

	/**
	 * Permite enviar un email a un usuario
	 * 
	 * @param receiver
	 * @param subject
	 * @param content
	 * @throws Exception
	 */
	public Boolean sendEmail(String receiver, String subject, String content) throws Exception;

}
