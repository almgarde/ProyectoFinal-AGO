--------------------------------------------------------
-- Archivo creado  - viernes-junio-10-2022   
--------------------------------------------------------
REM INSERTING into PF_AGO.AUTHORS_PUBLICATIONS
SET DEFINE OFF;
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('1','1','Francisco J. Garcia-Garcia',null,'Garcia-Garcia, F.J.');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('1','2','Mar�a J. Sayagu�s',null,'Sayagu�s, M.J.');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('1','3','Gotor Mart�nez, Francisco Jos�','4','Francisco J. Gotor');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('2','4','Alma Garc�a',null,'de la Obra, A. G. ');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('2','5','Mar�a Jes�s Sayagu�s',null,'Sayagu�s, M.J.');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('2','6','Ernesto Chicardi',null,'Chicardi, E.');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('2','7','Gotor Mart�nez, Francisco Jos�','4','Francisco J. Gotor');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('3','21','Irene Velo',null,'Velo, I.L.');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('3','22','Gotor Mart�nez, Francisco Jos�','4','Francisco J. Gotor');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('3','23','Mar�a Dolores Alcal�',null,'M.D.Alcal�');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('3','24','Real P�rez, Concepci�n','5','Real, C.');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('4','25','Mar�a Dolores Alcal�',null,'Alcal�, M.D.');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('4','26','Real P�rez, Concepci�n','5','Real, C.');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('4','27','Inmaculada Trigo',null,'I. Trigo');
Insert into PF_AGO.AUTHORS_PUBLICATIONS (ID_PUBLICATION,ID_AUTHOR,NAME_AUTHOR,ID_MEMBER,SHORT_NAME_AUTHOR) values ('4','28','Jos� Manuel C�rdoba',null,'C�rdoba, J.M.');

