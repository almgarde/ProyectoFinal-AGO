$(document).ready(function() {

	$("#forgetPwdForm").hide();
	$("#loginForm").show();
	$("#mensajesRecoveryPwd").hide();

	$(document).on("click", "#forgetPwdLink", function(e) {
		e.preventDefault();
		$("#forgetPwdForm").show();
		$("#loginForm").hide();
		$("#loginMensajeError").hide();
		$("#mensajesRecoveryPwd").hide();
		$("#emailAdminRecovery").val('');
		$("#usernameAdmin").val('');
		$("#passwordAdmin").val('');
	});

	$(document).on("click", "#loginLink", function(e) {
		e.preventDefault();
		$("#forgetPwdForm").hide();
		$("#loginForm").show();
		$("#mensajesRecoveryPwd").hide();
		$("#emailAdminRecovery").val('');
		$("#usernameAdmin").val('');
		$("#passwordAdmin").val('');
	});

	$(document).on("click", "#emailAdminRecoveryBtn", function(e) {

		var form = $("#forgetPwdForm");

		if (form[0].checkValidity() === false) {
			e.preventDefault();
			e.stopPropagation();
		} else {
			recuperarContraseña();
		}
		form.addClass('was-validated');

	});

});


function recuperarContraseña() {

	let form = new FormData();

	form.append("emailAdmin", $("#emailAdminRecovery").val());
	form.append("recoPwdAdminSubject", $("#recoPwdAdminSubject").val());
	form.append("recoPwdAdminSaludo", $("#recoPwdAdminSaludo").val());
	form.append("recoUsernameAdminReest", $("#recoUsernameAdminReest").val());
	form.append("recoPwdAdminReest", $("#recoPwdAdminReest").val());
	form.append("recoPwdAdminCarmbiarla", $("#recoPwdAdminCarmbiarla").val());

	$.ajax({
		url: '/recoveryPwd',
		type: "POST",
		processData: false,
		contentType: false,
		data: form,
		success: function(data) {
			$("#mensajesRecoveryPwd").show();
			$("#mensajesRecoveryPwd").removeClass('alert-danger');
			$("#mensajesRecoveryPwd").addClass('alert-success');
			$("#mensajesRecoveryPwd").text($("#userEmailsent").val());
			$("#emailAdminRecovery").val('');
		},
		error: function(e) {
			$("#mensajesRecoveryPwd").show();
			$("#mensajesRecoveryPwd").removeClass('alert-success');
			$("#mensajesRecoveryPwd").addClass('alert-danger');
			if (e.responseText == "userNotFound") {
				$("#mensajesRecoveryPwd").text($("#userNotFound").val());
			} else {
				$("#mensajesRecoveryPwd").text('Error');
			}

		}
	}).done(function() {
		$("#forgetPwdForm").removeClass('was-validated');
		$("#emailAdminRecovery").val('');
	});
}