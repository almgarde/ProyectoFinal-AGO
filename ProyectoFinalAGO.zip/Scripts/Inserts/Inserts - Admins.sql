--------------------------------------------------------
-- Archivo creado  - s�bado-junio-11-2022   
--------------------------------------------------------
REM INSERTING into PF_AGO.ADMINS
SET DEFINE OFF;
Insert into PF_AGO.ADMINS (ID_ADMIN,NAME_ADMIN,EMAIL_ADMIN,USER_ADMIN) values ('1','Administrador','administrador@hotmail.com','Admin');
