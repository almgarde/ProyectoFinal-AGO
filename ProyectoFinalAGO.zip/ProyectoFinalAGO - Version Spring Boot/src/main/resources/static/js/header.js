$(document).ready(function() {

	// IDIOMA

	$(".headerLang").removeClass("active");

	var lang = $("#lang").val();

	if (lang == "es") {
		$('#espLang').addClass("active");
	} else if (lang == "es_ES") {
		$('#espLang').addClass("active");
	} else if (lang == "en") {
		$('#engLang').addClass("active");
	} else {
		$('#frLang').addClass("active");
	}


	// PANTALLA ACTIVA

	$(".pantActive").removeClass("active");

	var pantActual = $("#pantallaActiva").val();

	if (pantActual == "home") {
		$('#homePant').addClass("active");
	} else if (pantActual == "facilities") {
		$('#facilitiesPant').addClass("active");
	} else if (pantActual == "links") {
		$('#linksPant').addClass("active");
	} else if (pantActual == "members") {
		$('#membersPant').addClass("active");
	} else if (pantActual == "projects") {
		$('#projectsPant').addClass("active");
	} else if (pantActual == "publications") {
		$('#publicationsPant').addClass("active");
	} else if (pantActual == "thesis") {
		$('#thesisPant').addClass("active");
	} else if (pantActual == "login") {
		$('#loginPant').addClass("active");
	} else if (pantActual == "panelGestion") {
		$('#gestionPant').addClass("active");
	} else {
		$(".pantActive").removeClass("active");
	}


	// DROPDOWN LOGIN 

	var inputUser = $('#inputUser').val();
	if (inputUser == "") {
		$('#loginOpt').show();
		$('#gestionOpt').hide();
		$('#logoutOpt').hide();
	} else {
		$('#loginOpt').hide();
		$('#gestionOpt').show();
		$('#logoutOpt').show();
	}


	// PANTALLA ACTIVA
	
	$(document).on("click", ".pantActive", function(e) {
		$('.pantActive').removeClass('active');
		$(this).addClass('active');
	});

});
