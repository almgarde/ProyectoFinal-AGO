function getDatatableAdmins() {

	let table = $('#adminsDatatable').DataTable({
		"sAjaxSource": "/management/getAdminsData",
		"sAjaxDataProp": "",
		"orderCellsTop": true,
		"fixedHeader": false,
		"bAutoWidth": false,
		"language": {
			"lengthMenu": $('#labelMostrando').val() + ' _MENU_ ' + $('#labelEntradas').val(),
			"emptyTable": $('#labelTablaVacia').val(),
			"search": $('#labelBuscador').val(),
			"zeroRecords": $('#labelNoCoincidencias').val(),
			"info": $('#labelMostrando').val() + ' _START_ ' + $('#labelA').val() + ' _END_ ' + $('#labelDe').val() + ' _TOTAL_ ' + $('#labelEntradas').val(),
			"infoEmpty": $('#labelMostrando').val() + " 0 " + $('#labelA').val() + ' 0 ' + $('#labelDe').val() + ' 0 ' + $('#labelEntradas').val(),
			"infoFiltered": '(' + $('#labelFiltrado').val() + ' _MAX_ ' + $('#labelEntradas').val() + ')',
			"loadingRecords": $('#labelCargando').val(),
			"paginate": {
				"next": $('#labelSiguiente').val(),
				"previous": $('#labelAnterior').val()
			},
		},
		"order": [[0, "desc"]],
		"aoColumns": [
			{
				"mData": "idAdmin",
				"mRender": function(data, type, row) {
					return data;
				},
				"bSortable": false
			},
			{
				"mData": "nameAdmin",
				"mRender": function(data, type, row) {
					return data;
				},
				"bSortable": false
			},
			{
				"mData": "emailAdmin",
				"mRender": function(data, type, row) {
					return data;
				},
				"bSortable": true
			},
			{
				"mData": "usernameAdmin",
				"mRender": function(data, type, row) {
					return data;
				},
				"bSortable": true
			}
		],
		"fnCreatedRow": function(row, data, index) {

			$('td:eq(0)', row).attr("data-label", $('#idDataLabel').val());
			$('td:eq(1)', row).attr("data-label", $('#nameAdminLabel').val());
			$('td:eq(2)', row).attr("data-label", $('#emailAdminLabel').val());
			$('td:eq(3)', row).attr("data-label", $('#usernameAdminLabel').val());

		}

	});

	$('#inputDeleteAdmins').val($('#inputUser').val());


	// FILTROS

	$('#adminsDatatable thead tr').clone(true).addClass('filters').appendTo('#adminsDatatable thead');

	$('#adminsDatatable thead tr.filters th').each(function() {
		$(this).off();
		$(this).removeClass('sorting_desc');
		$(this).removeClass('sorting');
	});

	$('#adminsDatatable thead tr:eq(1) th.atri').each(function(i) {

		$(this).html('<input type="text" />');

		$('input', this).on('keyup change', function() {
			if (table.column(i).search() != this.value) {
				table.column(i).search(this.value).draw();
			}
		});
	});
	

	// BOTONES

	$(document).on("click", "#btnAceptarAddAdmins", function(e) {

		$('#modalAddAdmins').modal('show');
		var form = $("#formAddAdmins");

		if (form[0].checkValidity() === false) {
			e.preventDefault();
			e.stopPropagation();
		} else {
			anyadirNuevoAdmin();
		}
		form.addClass('was-validated');

	});

	$(document).on("click", "#btnCancelarAddAdmins", function() {
		$("#formAddAdmins").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
		$("#nameAdmin").val('');
		$("#emailAdmin").val('');
		$("#usernameAdmin").val('');
		$("#pwdAdmin").val('');
		$("#pwdAdminAddConfirm").val('');
	});

	$(document).on("click", "#btnCloseAddAdmins", function() {
		$("#formAddAdmins").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
		$("#nameAdmin").val('');
		$("#emailAdmin").val('');
		$("#usernameAdmin").val('');
		$("#pwdAdmin").val('');
		$("#pwdAdminAddConfirm").val('');
	});

	$("#modalAddAdmins").on('hide.bs.modal', function() {
		$("#formAddAdmins").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
	});


	$(document).on("click", "#btnAceptarUpdateDataAdmins", function(e) {

		$('#modalUpdateDataAdmins').modal('show');
		var form = $("#formUpdateDataAdmins");

		if (form[0].checkValidity() === false) {
			e.preventDefault();
			e.stopPropagation();
		} else {
			actualizarDataAdmin();
		}
		form.addClass('was-validated');

	});

	$(document).on("click", "#btnCancelarUpdateDataAdmins", function() {
		$("#formUpdateDataAdmins").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');

	});

	$(document).on("click", "#btnCloseUpdateDataAdmins", function() {
		$("#formUpdateDataAdmins").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');

	});

	$("#modalUpdateDataAdmins").on('hide.bs.modal', function() {
		$("#formUpdateDataAdmins").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
	});


	$(document).on("click", "#btnAceptarPwdAdminActualAdmins", function(e) {

		$('#modalChangePwdAdmins').modal('show');
		var form = $("#formChangePwdAdmins");

		if (form[0].checkValidity() === false) {
			e.preventDefault();
			e.stopPropagation();
		} else {
			cambiarPwdAdmin();

		}
		form.addClass('was-validated');

	});

	$(document).on("click", "#btnCancelarChangePwdAdmins", function() {
		$("#formChangePwdAdmins").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
		$("#pwdAdminActual").val('');
		$("#pwdAdminNueva").val('');
		$("#pwdAdminConfirm").val('');
	});

	$(document).on("click", "#btnCloseChangePwdAdmins", function() {
		$("#formChangePwdAdmins").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
		$("#pwdAdminActual").val('');
		$("#pwdAdminNueva").val('');
		$("#pwdAdminConfirm").val('');
	});

	$("#modalChangePwdAdmins").on('hide.bs.modal', function() {
		$("#formChangePwdAdmins").removeClass('was-validated');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
	});

}


function mostrarModalAddAdmins() {
	$(".mensajeError").hide();
	$(".mensajeError").text('');
	$("#modalAddAdmins").modal('toggle');
}

function mostrarModalUpdateDataAdmins() {
	$(".mensajeError").hide();
	$(".mensajeError").text('');
	$('#nameAdminEdit').val($('#nameAdminInput').val());
	$('#emailAdminEdit').val($('#emailAdminInput').val());
	$("#modalUpdateDataAdmins").modal('toggle');
}

function mostrarModalChangePwdAdmins() {
	$(".mensajeError").hide();
	$(".mensajeError").text('');
	$("#modalChangePwdAdmins").modal('toggle');
}


// FUNCIONES CRUD

function anyadirNuevoAdmin() {

	let form = new FormData();
	form.append("nameAdmin", $("#nameAdmin").val());
	form.append("emailAdmin", $("#emailAdmin").val());
	form.append("usernameAdmin", $("#usernameAdmin").val());
	form.append("pwdAdmin", $("#pwdAdmin").val());
	form.append("pwdAdminConfirm", $("#pwdAdminAddConfirm").val());
	form.append("subjectNewAdmin", $("#subjectNewAdmin").val());
	form.append("welcomeNewAdmin", $("#welcomeNewAdmin").val());
	form.append("usernameNewAdmin", $("#usernameNewAdmin").val());
	form.append("passNewAdmin", $("#passNewAdmin").val());
	form.append("recoChangePwdAdmin", $("#recoChangePwdAdmin").val());

	$.ajax({
		url: '/management/addAdminsData',
		type: "POST",
		processData: false,
		contentType: false,
		data: form,
		success: function(data) {
			$('#adminsDatatable').DataTable().ajax.reload();
			okMessage();
			$(".alert").text($('#addOkMensaje').val());
		},
		error: function(e) {
			$('#modalAddAdmins').modal('show');
			$("#formAddAdmins").removeClass('was-validated');
			$(".mensajeError").show();

			if (e.responseText == "usernameAdminUnique") {
				$(".mensajeError").text($('#usernameAdminUnique').val());
			} else if (e.responseText == "emailAdminUnique") {
				$(".mensajeError").text($('#emailAdminUnique').val());
			} else if (e.responseText == "pswConfirmNoCoincide") {
				$(".mensajeError").text($('#pswConfirmNoCoincide').val());
			} else if (e.responseText == "errorAltaAdmin") {
				$(".mensajeError").text($('#errorAltaAdmin').val());
			} else {
				$(".mensajeError").hide();
				$(".mensajeError").text('');
				$('#modalAddAdmins').modal('hide');
				errorMessage();
				$(".alert").text($('#addErrorMensaje').val());
			}
		}
	}).done(function() {
		$("#formAddAdmins").removeClass('was-validated');
		$('#modalAddAdmins').modal('hide');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
		$("#nameAdmin").val('');
		$("#emailAdmin").val('');
		$("#usernameAdmin").val('');
		$("#pwdAdmin").val('');
		$("#pwdAdminAddConfirm").val('');
	});
}


function actualizarDataAdmin() {

	let form = new FormData();

	form.append("nameAdmin", $("#nameAdminEdit").val());
	form.append("emailAdmin", $("#emailAdminEdit").val());
	form.append("usernameAdmin", $("#inputUser").val());

	$.ajax({
		url: '/management/updateDataAdmins',
		type: "POST",
		processData: false,
		contentType: false,
		data: form,
		success: function(data) {
			$('#adminsDatatable').DataTable().ajax.reload();
			okMessage();
			$(".alert").text($('#updateOkMensaje').val());
			$("#nameAdminInput").val(form.get("nameAdmin"));
			$("#emailAdminInput").val(form.get("emailAdmin"));
		},
		error: function(e) {
			$('#modalUpdateDataAdmins').modal('show');
			$("#formUpdateDataAdmins").removeClass('was-validated');
			$(".mensajeError").show();

			if (e.responseText == "emailAdminUnique") {
				$(".mensajeError").text($('#emailAdminUnique').val());
			} else {
				$(".mensajeError").hide();
				$(".mensajeError").text('');
				$('#modalUpdateDataAdmins').modal('hide');
				errorMessage();
				$(".alert").text($('#updateErrorMensaje').val());
			}
		}
	}).done(function() {
		$("#formUpdateDataAdmins").removeClass('was-validated');
		$('#modalUpdateDataAdmins').modal('hide');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
	});
}


function cambiarPwdAdmin() {
	debugger;
	let form = new FormData();
	form.append("pwdAdminActual", $("#pwdAdminActual").val());
	form.append("pwdAdminNueva", $("#pwdAdminNueva").val());
	form.append("pwdAdminConfirm", $("#pwdAdminConfirm").val());
	form.append("usernameAdmin", $("#inputUser").val());

	$.ajax({
		url: '/management/changePwdAdmins',
		type: "POST",
		processData: false,
		contentType: false,
		data: form,
		success: function(data) {
			$('#adminsDatatable').DataTable().ajax.reload();
			okMessage();
			$(".alert").text($('#updateOkMensaje').val());
		},
		error: function(e) {
			$('#modalChangePwdAdmins').modal('show');
			$("#formChangePwdAdmins").removeClass('was-validated');
			$(".mensajeError").show();

			if (e.responseText == "pswActualMal") {
				$(".mensajeError").text($('#pswActualMal').val());
			} else if (e.responseText == "pswNuevaViejaIgual") {
				$(".mensajeError").text($('#pswNuevaViejaIgual').val());
			} else if (e.responseText == "pswConfirmNoCoincide") {
				$(".mensajeError").text($('#pswConfirmNoCoincide').val());
			} else {
				$(".mensajeError").hide();
				$(".mensajeError").text('');
				$('#modalChangePwdAdmins').modal('hide');
				errorMessage();
				$(".alert").text($('#updateErrorMensaje').val());
			}
		}
	}).done(function() {
		$("#formChangePwdAdmins").removeClass('was-validated');
		$('#modalChangePwdAdmins').modal('hide');
		$(".mensajeError").hide();
		$(".mensajeError").text('');
		$("#pwdAdminActual").val('');
		$("#pwdAdminNueva").val('');
		$("#pwdAdminConfirm").val('');
	});
}


