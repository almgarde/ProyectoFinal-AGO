package es.iessoterohernandez.ProyectoFinalAGO.Utils;

import javax.servlet.http.HttpServletResponse;

import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;

import es.iessoterohernandez.ProyectoFinalAGO.Services.Dto.Datatables.FacilitiesDatatableDto;
import es.iessoterohernandez.ProyectoFinalAGO.Services.Dto.Datatables.MembersDatatableDto;
import es.iessoterohernandez.ProyectoFinalAGO.Services.Dto.Datatables.NewsDatatableDto;
import es.iessoterohernandez.ProyectoFinalAGO.Services.Dto.Datatables.ProjectsDatatableDto;

public class GeneratorPdf {

	public void exportPdfNews(HttpServletResponse response, NewsDatatableDto news) throws Exception {

		Document document = new Document(PageSize.A4);

		PdfWriter.getInstance(document, response.getOutputStream());

		document.open();

		Font fontTitle = FontFactory.getFont(FontFactory.TIMES_BOLD);
		fontTitle.setSize(18);
		Paragraph paragraph = new Paragraph(news.getTitleNews(), fontTitle);
		paragraph.setAlignment(Paragraph.ALIGN_CENTER);

		String rutaImage = "src//main//resources//static//images//" + news.getImageNews();

		Image imageData = Image.getInstance(rutaImage);
		imageData.setAlignment(Image.MIDDLE);
		imageData.scaleAbsoluteWidth(300);
		imageData.scaleAbsoluteHeight(300);

		Font fontAbstract = FontFactory.getFont(FontFactory.TIMES_BOLD);
		fontAbstract.setSize(14);
		Paragraph paragraph2 = new Paragraph(news.getAbstractNews(), fontAbstract);
		paragraph2.setAlignment(Paragraph.ALIGN_LEFT);

		Font fontContent = FontFactory.getFont(FontFactory.TIMES);
		fontContent.setSize(14);
		Paragraph paragraph3 = new Paragraph(news.getContentNews(), fontContent);
		paragraph3.setAlignment(Paragraph.ALIGN_LEFT);

		document.add(paragraph);
		document.add(imageData);
		document.add(paragraph2);
		document.add(paragraph3);

		document.close();

	}

	public void exportPdfMember(HttpServletResponse response, MembersDatatableDto member) throws Exception {

		Document document = new Document(PageSize.A4);

		PdfWriter.getInstance(document, response.getOutputStream());

		document.open();

		String rutaImage = "src//main//resources//static//images//" + member.getPhotoMember();

		Image imageData = Image.getInstance(rutaImage);
		imageData.setAlignment(Image.MIDDLE);
		imageData.scaleAbsoluteWidth(300);
		imageData.scaleAbsoluteHeight(300);

		Font fontName = FontFactory.getFont(FontFactory.TIMES_BOLD);
		fontName.setSize(18);
		Paragraph paragraph = new Paragraph(member.getNameMember(), fontName);
		paragraph.setAlignment(Paragraph.ALIGN_CENTER);

		Font fontData = FontFactory.getFont(FontFactory.TIMES_BOLD);
		fontData.setSize(14);
		Paragraph paragraph2 = new Paragraph(member.getShortNameMember(), fontData);
		paragraph2.setAlignment(Paragraph.ALIGN_LEFT);
		Paragraph paragraph3 = new Paragraph("DNI/NIE: " + member.getDniMember(), fontData);
		paragraph2.setAlignment(Paragraph.ALIGN_LEFT);
		Paragraph paragraph4 = new Paragraph("Email: " + member.getEmailMember(), fontData);
		paragraph2.setAlignment(Paragraph.ALIGN_LEFT);
		Paragraph paragraph5 = new Paragraph("Tel: " + member.getPhoneMember(), fontData);
		paragraph2.setAlignment(Paragraph.ALIGN_LEFT);
		Paragraph paragraph6 = new Paragraph("ResearchID: " + member.getReseachIdMember(), fontData);
		paragraph2.setAlignment(Paragraph.ALIGN_LEFT);
		Paragraph paragraph7 = new Paragraph("ScopusID: " + member.getScopusIdMember(), fontData);
		paragraph2.setAlignment(Paragraph.ALIGN_LEFT);
		Paragraph paragraph8 = new Paragraph("Orcid ID: " + member.getOrcIdMember(), fontData);
		paragraph2.setAlignment(Paragraph.ALIGN_LEFT);

		Font fontTrajectory = FontFactory.getFont(FontFactory.TIMES);
		fontTrajectory.setSize(14);
		Paragraph paragraph9 = new Paragraph(member.getTrajectoryMember(), fontTrajectory);
		paragraph3.setAlignment(Paragraph.ALIGN_LEFT);

		document.add(imageData);
		document.add(paragraph);
		document.add(paragraph2);
		document.add(paragraph3);
		document.add(paragraph4);
		document.add(paragraph5);
		document.add(paragraph6);
		document.add(paragraph7);
		document.add(paragraph8);
		document.add(paragraph9);

		document.close();

	}

	public void exportPdfFacilities(HttpServletResponse response, FacilitiesDatatableDto facility) throws Exception {

		Document document = new Document(PageSize.A4);

		PdfWriter.getInstance(document, response.getOutputStream());

		document.open();

		Font fontTitle = FontFactory.getFont(FontFactory.TIMES_BOLD);
		fontTitle.setSize(18);
		Paragraph paragraph = new Paragraph(facility.getNameFacility(), fontTitle);
		paragraph.setAlignment(Paragraph.ALIGN_CENTER);

		String rutaImage = "src//main//resources//static//images//" + facility.getPhotoFacility();

		Image imageData = Image.getInstance(rutaImage);
		imageData.setAlignment(Image.MIDDLE);
		imageData.scaleAbsoluteWidth(300);
		imageData.scaleAbsoluteHeight(300);

		Font fontFeatures = FontFactory.getFont(FontFactory.TIMES);
		fontFeatures.setSize(14);
		Paragraph paragraph2 = new Paragraph(facility.getFeaturesFacility(), fontFeatures);
		paragraph2.setAlignment(Paragraph.ALIGN_LEFT);

		document.add(paragraph);
		document.add(imageData);
		document.add(paragraph2);

		document.close();

	}

	public void exportPdfProjects(HttpServletResponse response, ProjectsDatatableDto project) throws Exception {

		Document document = new Document(PageSize.A4);

		PdfWriter.getInstance(document, response.getOutputStream());

		document.open();

		Font fontTitle = FontFactory.getFont(FontFactory.TIMES_BOLD);
		fontTitle.setSize(18);
		Paragraph paragraph = new Paragraph(project.getTitleProject(), fontTitle);
		paragraph.setAlignment(Paragraph.ALIGN_CENTER);

		String rutaImage = "src//main//resources//static//images//" + project.getImageProject();

		Image imageData = Image.getInstance(rutaImage);
		imageData.setAlignment(Image.MIDDLE);
		imageData.scaleAbsoluteWidth(300);
		imageData.scaleAbsoluteHeight(300);

		Font fontDesacription = FontFactory.getFont(FontFactory.TIMES);
		fontDesacription.setSize(14);
		Paragraph paragraph2 = new Paragraph(project.getDescriptionProject(), fontDesacription);
		paragraph2.setAlignment(Paragraph.ALIGN_LEFT);

		document.add(imageData);
		document.add(paragraph);
		document.add(paragraph2);

		document.close();

	}

}
