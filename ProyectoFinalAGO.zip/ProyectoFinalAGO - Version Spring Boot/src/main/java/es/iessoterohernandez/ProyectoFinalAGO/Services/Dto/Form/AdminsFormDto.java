package es.iessoterohernandez.ProyectoFinalAGO.Services.Dto.Form;

public class AdminsFormDto {

	private String usernameAdmin;

	private String pwdAdmin;

	private String emailAdmin;

	public String getUsernameAdmin() {
		return usernameAdmin;
	}

	public void setUsernameAdmin(String usernameAdmin) {
		this.usernameAdmin = usernameAdmin;
	}

	public String getPwdAdmin() {
		return pwdAdmin;
	}

	public void setPwdAdmin(String pwdAdmin) {
		this.pwdAdmin = pwdAdmin;
	}

	public String getEmailAdmin() {
		return emailAdmin;
	}

	public void setEmailAdmin(String emailAdmin) {
		this.emailAdmin = emailAdmin;
	}

}
