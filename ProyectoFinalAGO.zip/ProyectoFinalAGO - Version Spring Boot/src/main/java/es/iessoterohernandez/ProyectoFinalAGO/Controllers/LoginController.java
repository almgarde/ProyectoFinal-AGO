package es.iessoterohernandez.ProyectoFinalAGO.Controllers;

import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import es.iessoterohernandez.ProyectoFinalAGO.Services.AdminServiceI;
import es.iessoterohernandez.ProyectoFinalAGO.Services.Dto.Form.AdminsFormDto;

/**
 * Controlador. Login
 * 
 * @author agadelao
 *
 */
@Controller
public class LoginController {

	final static Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	AdminServiceI adminService;

	@GetMapping("/login")
	public String index(Model model) {
		Locale lang = LocaleContextHolder.getLocale();
		model.addAttribute("adminsFormDto", new AdminsFormDto());
		model.addAttribute("lang", lang);
		return "/views/public/login";
	}

	@PostMapping("/recoveryPwd")
	public ResponseEntity recoveryPwd(Model model, @RequestParam Map<String, String> params) throws Exception {

		LOGGER.info("LoginController recoveryPwd .- Inicio");

		try {

			if (params != null && !params.isEmpty()) {
				adminService.recoveryPwd(params);
			} else {
				LOGGER.error("LoginController recoveryPwd .- Error: Parámetros de entrada nulos");
			}

		} catch (Exception e) {
			LOGGER.error("LoginController recoveryPwd .- Error no controlado al reestablecer la contraseña");
			return ResponseEntity.badRequest().body(e.getMessage());
		}

		LOGGER.info("LoginController recoveryPwd .- Fin");
		return ResponseEntity.ok("success");
	}

}
